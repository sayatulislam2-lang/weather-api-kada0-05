async function getWeather() {
  const city = document.getElementById('cityInput').value;
  const result = document.getElementById('result');
  const emoji = document.getElementById('emoji');

  if (!city) {
    result.textContent = 'Please enter a city name.';
    return;
  }

  try {
    const res = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=YOUR_API_KEY&units=metric`);
    const data = await res.json();

    if (data.cod !== 200) {
      result.textContent = 'City not found.';
      document.body.className = '';
      emoji.textContent = '';
      return;
    }

    const weather = data.weather[0].main.toLowerCase();
    const temp = data.main.temp;
    result.textContent = `Weather in ${city}: ${weather}, ${temp}°C`;

    document.body.className = '';
    emoji.textContent = '';

    switch (weather) {
      case 'clear':
        document.body.classList.add('clear');
        emoji.textContent = '☀️';
        break;
      case 'clouds':
        document.body.classList.add('cloudy');
        emoji.textContent = '☁️';
        break;
      case 'rain':
        document.body.classList.add('rainy');
        emoji.textContent = '🌧️';
        break;
      case 'sunny':
        document.body.classList.add('sunny');
        emoji.textContent = '🌞';
        break;
      default:
        document.body.classList.add('cloudy');
        emoji.textContent = '🌤️';
    }
  } catch (error) {
    result.textContent = 'Error fetching weather.';
    console.error(error);
  }
}